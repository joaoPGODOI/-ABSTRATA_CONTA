package main;

public abstract class ContaBancaria {
     
	//Atributos titular e saldo
     private String titular;
     private double saldo;
     
     
     public ContaBancaria(String titular, double saldo) {
    	 
    	 this.titular = titular;
    	 this.saldo = saldo;
     }
	
	      //Métodos abstratos
		public abstract void saque(double valor);
		public abstract void depósito(double valor);
		public abstract void consulta();
		
		
		
	     //Classe herdeira conta poupança
		 public class ContaPoupança extends ContaBancaria{
              private final double taxa_Saque = 0.01;
			  private final double taxa_Deposito = 0.006;
			 
			public ContaPoupança(String titular, double saldo) {
				super(titular, saldo);
			}
           
			//aplica o valor da taxa e confere se o valor não ultrapassa o saldo
			@Override
			public void saque(double valor) {
				double valorTaxa = valor + (valor * taxa_Saque);
				if(valor >= saldo) {
					System.out.println("Saque no valor de R$" + valor + "realizado com sucesso.Taxa de:" + (valor * taxa_Saque));
				}
				else {
					System.out.println("Saldo insuficiente.");
				}
			}

			@Override
			public void depósito(double valor) {
			   double valorTaxa2 = valor - (valor + taxa_Deposito);
			   System.out.println("Depósito no valor R$" + valor + "realizado com sucesso. Taxa de:" + (valor * taxa_Deposito) );
				
			}

			@Override
			public void consulta() {
                System.out.println("Valor do saldo atual: R$" + saldo);				
			}
			 
			 
		 }
		 
		 //Classe herdeira conta corrente
	public class ContaCorrente extends ContaBancaria{
             private final double taxa_saque = 0.02;
             private final double taxa_deposito = 0.003;
			 private double limite;
			 
			public ContaCorrente(String titular, double saldo,double limite) {
				super(titular, saldo);
				this.limite = limite;
			}

			//aplica o valor da taxa e confere o limite
			@Override
		public void saque(double valor) {
            double valortaxa = valor + (valor * taxa_saque);
            if(valor >= limite) {
            	System.out.println("Saque no valor R$" + valor +"reaizado com sucesso. Taxa aplicada R$" + (valor * taxa_saque));
            }
               else {
            	   System.out.println("Saldo e limite insuficientes para realizar o saque.");
               }
	    }

			@Override
			public void depósito(double valor) {
				double valortaxa2 = valor - (valor * taxa_deposito);
				System.out.println("Depósito no valor de R$" + valor + "realizado com sucesso. Taxa no valor de R$" + (valor * taxa_deposito));
			}

			@Override
			public void consulta() {
				System.out.println("Saldo da conta corrente R$"+ saldo);
				System.out.println("Limite disponível R$" + limite);
				
			} 
	}
}

	


